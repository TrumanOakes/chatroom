import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.time.LocalDateTime;

public class Client {
    private final int myPort;
    private static final String SERVER_HOST = "127.0.0.1";
    private static final int SERVER_PORT = 9999;
    private PrintWriter log;
    private boolean done;

    public Client(int port) {
        this.myPort = port;
    }

    public static void main(String[] args) {
        int port;
        if (args.length == 1) {
            try { port = Integer.parseInt(args[0]); }
            catch (NumberFormatException e) { System.err.println("Invalid port."); return; }
        } else {
            BufferedReader console = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Enter listening port: ");
            try { port = Integer.parseInt(console.readLine().trim()); }
            catch (Exception e) { System.err.println("Failed reading port."); return; }
        }
        new Client(port).start();
    }

    private void start() {
        try (ServerSocket listener = new ServerSocket(myPort)) {
            log = new PrintWriter(new FileWriter("client" + myPort + ".log", true), true);
            logEvent("Listening on port " + myPort);

            Socket ctrl = new Socket(SERVER_HOST, SERVER_PORT);
            BufferedReader cin = new BufferedReader(new InputStreamReader(ctrl.getInputStream()));
            PrintWriter cout = new PrintWriter(ctrl.getOutputStream(), true);
            cout.println("REGISTER:" + myPort);

            String reply = cin.readLine();
            if (reply == null) { System.err.println("Server closed."); return; }
            String[] parts = reply.split(":", 4);
            String peerIp = parts[1];
            int peerPort = Integer.parseInt(parts[2]);
            String role = parts[3];
            logEvent("Received peer=" + peerIp + ":" + peerPort + " role=" + role);

            Socket peerSock;
            if ("INITIATOR".equals(role)) {
                Thread.sleep(500);
                peerSock = new Socket(peerIp, peerPort);
            } else {
                peerSock = listener.accept();
            }
            logEvent("Peer connected: " + peerSock.getRemoteSocketAddress());
            startChat(peerSock);

        } catch (Exception e) {
            e.printStackTrace(); shutdown();
        }
    }

    private void startChat(Socket peer) throws IOException {
        BufferedReader inPeer = new BufferedReader(new InputStreamReader(peer.getInputStream()));
        PrintWriter outPeer = new PrintWriter(peer.getOutputStream(), true);
        new Thread(() -> {
            try {
                String line;
                while ((line = inPeer.readLine()) != null) {
                    System.out.println("Peer: " + line);
                    logToFile("RECEIVED: " + line);
                }
                logToFile("RECEIVED: Peer disconnected");
            } catch (IOException ignored) {}
        }).start();

        BufferedReader userIn = new BufferedReader(new InputStreamReader(System.in));
        String msg;
        while (!done && (msg = userIn.readLine()) != null) {
            outPeer.println(msg);
            logToFile("SENT: " + msg);
            if ("/quit".equalsIgnoreCase(msg.trim())) { shutdown(); break; }
        }
        peer.close(); logEvent("Chat ended");
    }

    private void logToFile(String msg) {
        log.println(LocalDateTime.now() + "  " + msg);
    }

    private void logEvent(String msg) {
        log.println(LocalDateTime.now() + "  " + msg);
        System.out.println("[Client] " + msg);
    }

    private void shutdown() { done = true; }
}