// 100% Truman
import javax.swing.*;
import javax.swing.SwingUtilities;
import java.awt.*;
import java.io.*;
import java.net.*;
import java.time.LocalDateTime;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

public class ChatGUI extends JFrame {
    private JTextArea chatArea;
    private JTextField inputField;
    private JButton sendButton;
    private JButton connectButton;
    private JTextField controllerHostField;
    private JTextField controllerPortField;
    private JTextField peerHostField;
    private JTextField peerPortField;
    private JTextField listenField;

    private volatile Socket peerSocket;
    private PrintWriter out;
    private BufferedReader in;
    private PrintWriter clientLog; 

    public ChatGUI() {
        super("P2P Chat");
        initComponents();
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(850, 550);
        setLocationRelativeTo(null);
    }

    private void initComponents() {
        chatArea = new JTextArea();
        chatArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(chatArea);

        inputField = new JTextField();
        inputField.setEnabled(false);
        sendButton = new JButton("Send");
        sendButton.setEnabled(false);

        connectButton = new JButton("Connect");
        controllerHostField = new JTextField(20);
        controllerPortField = new JTextField(6);
        peerHostField = new JTextField(20);
        peerPortField = new JTextField(6);
        listenField = new JTextField(6);

        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        controlPanel.add(new JLabel("Controller Host:"));
        controlPanel.add(controllerHostField);
        controlPanel.add(new JLabel("Controller Port:"));
        controlPanel.add(controllerPortField);
        controlPanel.add(new JLabel("Peer Host:"));
        controlPanel.add(peerHostField);
        controlPanel.add(new JLabel("Peer Port:"));
        controlPanel.add(peerPortField);
        controlPanel.add(new JLabel("Listen Port:"));
        controlPanel.add(listenField);
        controlPanel.add(connectButton);

        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.add(inputField, BorderLayout.CENTER);
        bottomPanel.add(sendButton, BorderLayout.EAST);

        Container cp = getContentPane();
        cp.setLayout(new BorderLayout());
        cp.add(controlPanel, BorderLayout.NORTH);
        cp.add(scrollPane, BorderLayout.CENTER);
        cp.add(bottomPanel, BorderLayout.SOUTH);

        connectButton.addActionListener(e -> {
            connectButton.setEnabled(false);
            String ctrlHost = controllerHostField.getText().trim();
            int ctrlPort = Integer.parseInt(controllerPortField.getText().trim());
            String peerHost = peerHostField.getText().trim();
            int peerPort = Integer.parseInt(peerPortField.getText().trim());
            int myPort = Integer.parseInt(listenField.getText().trim());
            new Thread(() -> runClient(ctrlHost, ctrlPort, peerHost, peerPort, myPort)).start();
        });
        sendButton.addActionListener(e -> sendMessage());
        inputField.addActionListener(e -> sendMessage());
    }

    private void runClient(String controllerHost, int ctrlPort,
                           String peerHost, int peerPort,
                           int myPort) {
        // open log file
        try {
            clientLog = new PrintWriter(new FileWriter("client" + myPort + ".log", true), true);
            clientLog.println(LocalDateTime.now() + "  START client on port " + myPort);
        } catch (IOException ioe) {
            append("Error opening log: " + ioe.getMessage());
        }

        append("DEBUG: controllerHost='" + controllerHost + "'");
        append("DEBUG: controllerPort=" + ctrlPort);
        append("DEBUG: peerHost='" + peerHost + "'");
        append("DEBUG: peerPort=" + peerPort);
        append("DEBUG: listenPort=" + myPort);

        try (ServerSocket listener = new ServerSocket(myPort);
             Socket ctrl = new Socket(controllerHost, ctrlPort);
             BufferedReader cin = new BufferedReader(
                     new InputStreamReader(ctrl.getInputStream()));
             PrintWriter cout = new PrintWriter(
                     ctrl.getOutputStream(), true)) {

            append("Listening on port " + myPort);
            cout.println("REGISTER:" + peerHost + ":" + peerPort);
            append("DEBUG: sent REGISTER:" + peerHost + ":" + peerPort);

            String reply = cin.readLine();
            if (reply == null) {
                append("Controller closed connection.");
                logEvent("Controller closed connection");
                SwingUtilities.invokeLater(() -> connectButton.setEnabled(true));
                return;
            }
            append("DEBUG: server replied='" + reply + "'");
            String[] parts = reply.split(":", 4);
            String theirIp = parts[1];
            int theirPort = Integer.parseInt(parts[2]);
            String role = parts[3];
            append("Received peer=" + theirIp + ":" + theirPort + " role=" + role);

            if ("INITIATOR".equals(role)) {
                Thread.sleep(500);
                peerSocket = new Socket(theirIp, theirPort);
            } else {
                peerSocket = listener.accept();
            }
            append("Connected to peer: " + peerSocket.getRemoteSocketAddress());
            logEvent("Connected to peer: " + peerSocket.getRemoteSocketAddress());

            SwingUtilities.invokeLater(() -> {
                sendButton.setEnabled(true);
                inputField.setEnabled(true);
                inputField.requestFocusInWindow();
            });

            out = new PrintWriter(peerSocket.getOutputStream(), true);
            in = new BufferedReader(
                    new InputStreamReader(peerSocket.getInputStream()));

            String line;
            while ((line = in.readLine()) != null) {
                append("Peer: " + line);
                logEvent("RECEIVED: " + line);
                if ("bye".equalsIgnoreCase(line.trim())) {
                    append("Peer said bye, closing connection.");
                    logEvent("Peer said bye, closing connection.");
                    break;
                }
            }
            append("Peer disconnected.");
            logEvent("Peer disconnected.");
        } catch (Exception ex) {
            append("Error: " + ex.getMessage());
            logEvent("Error: " + ex.getMessage());
            SwingUtilities.invokeLater(() -> connectButton.setEnabled(true));
        } finally {
            try {
                if (peerSocket != null) peerSocket.close();
                if (clientLog != null) clientLog.close();
            } catch (IOException ignored) {}
        }
    }

    private void sendMessage() {
        if (out == null) return;
        String msg = inputField.getText().trim();
        if (msg.isEmpty()) return;
        out.println(msg);
        append("Me: " + msg);
        logEvent("SENT: " + msg);
        inputField.setText("");
        if ("bye".equalsIgnoreCase(msg)) {
            append("You said bye, closing.");
            logEvent("You said bye, closing.");
            try { peerSocket.close(); } catch (IOException ignored) {}
            SwingUtilities.invokeLater(() -> {
                sendButton.setEnabled(false);
                inputField.setEnabled(false);
            });
        }
    }

    private void append(String text) {
        SwingUtilities.invokeLater(() -> {
            chatArea.append(text + "\n");
            chatArea.setCaretPosition(chatArea.getDocument().getLength());
        });
        if (clientLog != null) clientLog.println(LocalDateTime.now() + "  " + text);
    }

    private void logEvent(String msg) {
        if (clientLog != null) clientLog.println(LocalDateTime.now() + "  " + msg);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ChatGUI().setVisible(true));
    }
}
