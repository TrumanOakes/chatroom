// 60% William 40% Truman

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.time.LocalDateTime;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Server {
    private static final int PORT = 9999;

    private final ExecutorService pool = Executors.newFixedThreadPool(2);
    private final Registration[] regs = new Registration[2];
    private int count = 0;
    private PrintWriter log;

    public static void main(String[] args) {
        new Server().start();
    }

    private void start() {
        try (ServerSocket server = new ServerSocket(PORT)) {
            log = new PrintWriter(new FileWriter("controller.log", true), true);
            logEvent("Server started on port " + PORT);

            while (true) {
                Socket sock = server.accept();
                pool.execute(() -> registerClient(sock));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private synchronized void registerClient(Socket sock) {
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
            PrintWriter out = new PrintWriter(sock.getOutputStream(), true);
            String line = in.readLine();
            if (line != null && line.startsWith("REGISTER:")) {
                String[] parts = line.split(":", 3);
                if (parts.length == 3) {
                    String ip = parts[1];
                    int port = Integer.parseInt(parts[2]);
                    regs[count] = new Registration(sock, out, ip, port);
                    logEvent("Client " + (count + 1) + " registered at " + ip + ":" + port);
                    count++;
                } else {
                    logEvent("Invalid registration format: " + line);
                    sock.close();
                    return;
                }
            } else {
                logEvent("Invalid registration: " + line);
                sock.close();
                return;
            }
            if (count == 2) {
                // exchange peers
                Registration a = regs[0], b = regs[1];
                a.out.println("PEER:" + b.ip + ":" + b.port + ":LISTENER");
                b.out.println("PEER:" + a.ip + ":" + a.port + ":INITIATOR");
                logEvent("Exchanged peers: " + a.ip + ":" + a.port + " <-> " + b.ip + ":" + b.port);

                for (Registration r : regs) {
                    try { r.sock.close(); } catch (IOException ignored) {}
                }

                regs[0] = regs[1] = null;
                count = 0;
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    private void logEvent(String msg) {
        String stamp = LocalDateTime.now().toString();
        log.println(stamp + "  " + msg);
        System.out.println("[Server] " + msg);
    }

    private static class Registration {
        final Socket sock;
        final PrintWriter out;
        final String ip;
        final int port;

        Registration(Socket sock, PrintWriter out, String ip, int port) {
            this.sock = sock;
            this.out = out;
            this.ip = ip;
            this.port = port;
        }
    }
}
